﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week7_8.Reading
{
    public interface IPrintable
    {
        string HardCopySource();
    }
}
